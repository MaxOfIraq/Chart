//
//  ContentView.swift
//  Chart
//
//  Created by Ahmed Salah on 26/09/2022.
//

import SwiftUI
import Charts


struct Programer : Identifiable, Hashable{
    
    var id = UUID()
    let number : Int
}

struct ContentView: View {
    
    @State var programer = [
    
        Programer(number: 10),
        Programer(number: 13),
        Programer(number: 16),
        Programer(number: 20),
        Programer(number: 30),
        Programer(number: 31),
        Programer(number: 33),
        Programer(number: 37),
        Programer(number: 40),
        Programer(number: 49),
        
    ]
    
    
    var body: some View {
        ScrollView{
            Spacer()
            VStack(spacing: 70){
                Text("Apple Programer")
                    .font(.title)
                    .fontWeight(.bold)
                Chart([10,20,30,40], id: \.self){ proLimt in
                    BarMark(
                        x:.value("", "\(proLimt)"),
                        y: .value("", numberr(proLimt))
                    ).annotation(position: .top, alignment: .center, spacing: 10) {
                        Text("\(name(proLimt)) \(numberr(proLimt))")
                            .font(.title3)
                            .fontWeight(.bold)
                    }
                }.padding()
                    .frame(height: 400)
            }
        }
    }
    
    func numberr(_ proLimt: Int)-> Int{
        programer.filter{$0.number >= proLimt && $0.number < proLimt + 10}.count
    }
    
    func name(_ proLimt: Int)-> String{
        switch proLimt{
        case 10...19 : return "Swift"
        case 20...29 : return "Swift"
        case 30...39 : return "Swift"
        case 40...49 : return "Swift"
        default:
            return "Unone"
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
